# -*- coding: utf-8 -*-
# from odoo import http


# class Sonia(http.Controller):
#     @http.route('/sonia/sonia', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/sonia/sonia/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('sonia.listing', {
#             'root': '/sonia/sonia',
#             'objects': http.request.env['sonia.sonia'].search([]),
#         })

#     @http.route('/sonia/sonia/objects/<model("sonia.sonia"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('sonia.object', {
#             'object': obj
#         })
