# -*- coding: utf-8 -*-

from . import models
from . import agama
from . import fakultas
from . import anggota
from . import jabatan