from odoo import models, fields, api

class agama(models.Model):
    _name = 'sonia.agama'
    _description = 'Menyimpan Data Agama'

    name = fields.Char()
