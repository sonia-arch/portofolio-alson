from odoo import models, fields, api

class anggota(models.Model):
    _name = 'sonia.anggota'
    _description = 'Menyimpan Data Anggota'

    nomor = fields.Char()
    name = fields.Char()
    alamat = fields.Char()
    jabatan = fields.Char()
