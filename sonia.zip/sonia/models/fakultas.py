from odoo import models, fields, api

class fakultas(models.Model):
    _name = 'sonia.fakultas'
    _description = 'Menyimpan Data Fakultas'

    name = fields.Char()
   