from odoo import models, fields, api

class agama(models.Model):
    _name = 'sonia.jabatan'
    _description = 'Menyimpan Data Jabatan'

    name = fields.Char()